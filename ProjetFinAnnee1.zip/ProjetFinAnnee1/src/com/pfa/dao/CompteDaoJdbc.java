package com.pfa.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.pfa.jpa.Compte;

public class CompteDaoJdbc implements CompteDao{
	private Session session;
	public CompteDaoJdbc() {
		// TODO Auto-generated constructor stub
	}
	public CompteDaoJdbc(Session session) {
		super();
		this.session = session;
	}
	public Session getSession() {
		return session;
	}
	public void setSession(Session session) {
		this.session = session;
	}
	@Override
	public boolean insert(Compte compte) {
		try {
			Transaction t=session.beginTransaction();
			session.persist(compte);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	@Override
	public boolean update(Compte compte) {
		try {
			Transaction t=session.beginTransaction();
			session.update(compte);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	@Override
	public Compte select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Compte where code_compte ="+code);
		Compte compte=(Compte)q.uniqueResult();
		t.commit();
		return compte;
	}
	@Override
	public List<Compte> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Compte");
		List<Compte> comptes=(List<Compte>)q.list();
		t.commit();
		return comptes;
	}
	@Override
	public boolean delete(int code) {
		try {
			Transaction t=session.beginTransaction();
			Query q=session.createQuery("from Compte where code_compte ="+code);
			Compte compte=(Compte)q.uniqueResult();
			session.delete(compte);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	@Override
	public Compte select(String login, String password) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Compte where login='"+login+"' and password='"+password+"'");
		System.out.println(q.getQueryString());
		Compte compte=(Compte)q.uniqueResult();
		t.commit();
		return compte;
	}
	
}
