package com.pfa.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.pfa.jpa.ClientMorale;
import com.pfa.jpa.Docteur;
import com.pfa.jpa.Secretaire;
import com.pfa.jpa.Secretaire;
import com.pfa.jpa.Secretaire;

public class SecretaireDaoJdbc implements SecretaireDao{
	Session session;
	
	public SecretaireDaoJdbc() {
		
	}

	public SecretaireDaoJdbc(Session session) {
		super();
		this.session = session;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	@Override
	public boolean insert(Secretaire secretaire) {
		
			try {
				Transaction t=session.beginTransaction();
				session.persist(secretaire);
				t.commit();
				return true;
			} catch (HibernateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
		
		
	}

	@Override
	public boolean update(Secretaire secretaire) {
		
			try {
				Transaction t=session.beginTransaction();
				session.update(secretaire);
				t.commit();
				return true;
			} catch (HibernateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
		
	}

	@Override
	public Secretaire select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from user where user_code= "+code);
		Secretaire secretaire=(Secretaire)q.uniqueResult();
		t.commit();
		return secretaire;
	}

	@Override
	public List<Secretaire> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from user");
		ArrayList<Secretaire> list=(ArrayList<Secretaire>)q.list();
		t.commit();
		return list;
	}

	@Override
	public boolean delete(int code) {
		
			try {
				Transaction t=session.beginTransaction();
				Secretaire secretaire=select(code);
				session.delete(secretaire);
				t.commit();
				return true;
			} catch (HibernateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
		
		
	}

	@Override
	public Secretaire select(String key, String value) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from User where "+key+"="+value);
		Secretaire secretaire=(Secretaire)q.uniqueResult();
		t.commit();
		return secretaire;
	}

	
}
