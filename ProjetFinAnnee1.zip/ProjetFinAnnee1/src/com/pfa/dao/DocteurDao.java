package com.pfa.dao;
import java.util.ArrayList;
import java.util.List;

import com.pfa.jpa.Docteur;


public interface DocteurDao {

	public boolean insert(Docteur doc);
	public boolean update(Docteur doc);
	public Docteur select(int code);
	public Docteur select(String key,String value);
	public ArrayList<Docteur> selectAll();
	public boolean delete(int code);
}
