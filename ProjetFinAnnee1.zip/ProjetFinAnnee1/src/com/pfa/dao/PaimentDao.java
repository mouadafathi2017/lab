package com.pfa.dao;

import java.util.List;

import com.pfa.jpa.Paiment;


public interface PaimentDao {

	public boolean insert(Paiment p);
	public boolean update(Paiment p);
	public Paiment select(int code);
	public List<Paiment> select(String key,String value);
	public List<Paiment> selectAll();
	public boolean delete(int code);
}
