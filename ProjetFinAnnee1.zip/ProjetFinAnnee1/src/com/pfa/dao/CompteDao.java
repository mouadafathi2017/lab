package com.pfa.dao;

import java.util.List;

import com.pfa.jpa.Compte;

public interface CompteDao {
	public boolean insert(Compte compte);
	public boolean update(Compte compte);
	public Compte select(int code);
	public Compte select(String login,String password);
	public List<Compte> selectAll();
	public boolean delete(int code);
}
