package com.pfa.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.pfa.jpa.Analyse;
import com.pfa.jpa.Bilan;

public class BilanDaoJdbc implements BilanDao{
	private Session session;
	
	public BilanDaoJdbc() {
	}

	public BilanDaoJdbc(Session session) {
		super();
		this.session = session;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	@Override
	public boolean insert(Bilan bilan) {
		try {
			Transaction t=session.beginTransaction();
			session.persist(bilan);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}

	@Override
	public boolean update(Bilan bilan) {
		try {
			Transaction t=session.beginTransaction();
			session.update(bilan);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}

	@Override
	public Bilan select(int bilan_id) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Bilan where id= "+bilan_id);
		Bilan bilan=(Bilan)q.uniqueResult();
		t.commit();
		return bilan;
	}

	@Override
	public List<Bilan> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Bilan");
		ArrayList<Bilan> list=(ArrayList<Bilan>)q.list();
		t.commit();
		return list;
	}

	@Override
	public boolean delete(int bilan_id) {
		try {
			Transaction t=session.beginTransaction();
			Bilan bilan=select(bilan_id);
			session.delete(bilan);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

}
