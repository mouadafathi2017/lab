package com.pfa.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.pfa.jpa.ClientMorale;
import com.pfa.jpa.ClientPhysique;

public class ClientPhysiqueDaoJdbc implements ClientPhysiqueDao{
	private Session session;
	public ClientPhysiqueDaoJdbc() {
		
	}
	public ClientPhysiqueDaoJdbc(Session session) {
		super();
		this.session = session;
	}
	public Session getSession() {
		return session;
	}
	public void setSession(Session session) {
		this.session = session;
	}
	@Override
	public boolean insert(ClientPhysique client) {
		try {
			Transaction t=session.beginTransaction();
			session.persist(client);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	@Override
	public boolean update(ClientPhysique client) {
		try {
			Transaction t=session.beginTransaction();
			session.update(client);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	@Override
	public ClientPhysique select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from User where code="+code);
		ClientPhysique client=(ClientPhysique)q.uniqueResult();
		t.commit();
		return client;
	}
	@Override
	public List<ClientPhysique> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from User");
		ArrayList<ClientPhysique> clients=(ArrayList<ClientPhysique>)q.list();
		t.commit();
		return clients;
	}
	@Override
	public boolean delete(int code) {
		try {
			Transaction t=session.beginTransaction();
			Query q=session.createQuery("from User where code="+code);
			ClientPhysique client=(ClientPhysique)q.uniqueResult();
			session.delete(client);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	public ClientPhysique select(String key, String value) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from User where "+key+"="+value);
		ClientPhysique client=(ClientPhysique)q.uniqueResult();
		t.commit();
		return client;
	}
	
	
}
