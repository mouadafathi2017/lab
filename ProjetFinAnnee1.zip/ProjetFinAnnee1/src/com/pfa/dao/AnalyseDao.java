package com.pfa.dao;

import java.util.List;

import com.pfa.jpa.Analyse;

public interface AnalyseDao {

		public boolean insert(Analyse analyse);
		public boolean update(Analyse analyse);
		public Analyse select(int code);
		public List<Analyse> select(String key,String value);
		public List<Analyse> selectAll();
		public List<Analyse> selectAll(int code_bilan);
		public boolean delete(int code);
}
