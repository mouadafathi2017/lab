package com.pfa.dao;

import java.util.List;

import com.pfa.jpa.ClientMorale;

public interface ClientMoraleDao {
	public boolean insert(ClientMorale client);
	public boolean update(ClientMorale client);
	public ClientMorale select(int code);
	public ClientMorale select(String key,String value);
	public List<ClientMorale> selectAll();
	public boolean delete(int code);
}
