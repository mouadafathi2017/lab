package com.pfa.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.pfa.jpa.Bilan;
import com.pfa.jpa.RendezVous;

public class RendezVousDaoJdbc implements RendezVousDao{
	public Session session;
	
	public RendezVousDaoJdbc() {
		
	}

	public RendezVousDaoJdbc(Session session) {
		super();
		this.session = session;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	@Override
	public boolean insert(RendezVous rdv) {
		
			try {
				Transaction t=session.beginTransaction();
				session.persist(rdv);
				t.commit();
				return true;
			} catch (HibernateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
		
		
	}

	@Override
	public boolean update(RendezVous rdv) {
		
		try {
			Transaction t=session.beginTransaction();
			session.update(rdv);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
	}

	@Override
	public RendezVous select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from RendezVous where RendezVous_code= "+code);
		RendezVous rdv=(RendezVous)q.uniqueResult();
		t.commit();
		return rdv;
	}

	@Override
	public List<RendezVous> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from RendezVous");
		ArrayList<RendezVous> list=(ArrayList<RendezVous>)q.list();
		t.commit();
		return list;
	}
	public List<RendezVous> selectAll(int code_client) {
		
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from RendezVous where rdv_client_id="+code_client);
		
		List<RendezVous> list=(ArrayList<RendezVous>)q.list();
		t.commit();
		for(RendezVous rdv:list)System.out.println(rdv);
		return list;
	}
	@Override
	public boolean delete(int code) {
		try {
			Transaction t=session.beginTransaction();
			Query q=session.createQuery("from RendezVous where code= "+code);
			RendezVous rdv=(RendezVous)q.uniqueResult();System.out.println(rdv);
			session.delete(rdv);
			t.commit();
			System.out.println("kolchi daz mezyan");
			return true;
		} catch (HibernateException e) {System.out.println(e.getMessage());
			return false;
		}
	}
	
}
