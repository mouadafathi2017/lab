package com.pfa.dao;

import java.util.List;

import com.pfa.jpa.Secretaire;

public interface SecretaireDao {
	public boolean insert(Secretaire secretaire);
	public boolean update(Secretaire secretaire);
	public Secretaire select(int code);
	public Secretaire select(String key,String value);
	public List<Secretaire> selectAll();
	public boolean delete(int code);
}
