package com.pfa.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.pfa.jpa.Analyse;
import com.pfa.jpa.Bilan;

public class AnalyseDaoJdbc implements AnalyseDao{
	
	private Session session;
	
	public AnalyseDaoJdbc() {
		
	}
	public AnalyseDaoJdbc(Session session){
		this.session=session;
	}
	public Session getSession() {
		return session;
	}
	public void setSession(Session session) {
		this.session = session;
	}
	
	@Override
	public boolean insert(Analyse analyse) {
		
		try {
			Transaction t=session.beginTransaction();
			session.persist(analyse);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	@Override
	public boolean update(Analyse analyse) {
   	  try {
		Transaction t=session.beginTransaction();
		  session.update(analyse);
		  t.commit();
		  return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return false;
	}
   	  
	}
	@Override
	public Analyse select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Analyse where code= :code");
		q.setString("code",""+code);
		Analyse analyse=(Analyse)q.uniqueResult();
		t.commit();
		return analyse;
	}
	@Override
	public List<Analyse> select(String key, String value) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Analyse where "+key+"="+value);
		ArrayList<Analyse> list=(ArrayList<Analyse>)q.list();
		t.commit();
		return list;
	}
	@Override
	public List<Analyse> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Analyse");
		ArrayList<Analyse> list=(ArrayList<Analyse>)q.list();
		t.commit();
		return list;
	}
	@Override
	public boolean delete(int code) {
		try {
			Transaction t=session.beginTransaction();
			Analyse analyse=select(code);
			session.delete(analyse);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	@Override
	public List<Analyse> selectAll(int code_bilan) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Analyse where analyse_bilanID="+code_bilan);
		ArrayList<Analyse> list=(ArrayList<Analyse>)q.list();
		t.commit();
		return list;
	}
	
	
}
