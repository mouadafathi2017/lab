package com.pfa.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.pfa.jpa.ClientMorale;

public class ClientMoraleDaoJdbc implements ClientMoraleDao{
	private Session session;
	public ClientMoraleDaoJdbc() {
		
	}
	public ClientMoraleDaoJdbc(Session session) {
		super();
		this.session = session;
	}
	public Session getSession() {
		return session;
	}
	public void setSession(Session session) {
		this.session = session;
	}
	@Override
	public boolean insert(ClientMorale client) {
		try {
			Transaction t=session.beginTransaction();
			session.persist(client);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	@Override
	public boolean update(ClientMorale client) {
		try {
			Transaction t=session.beginTransaction();
			session.update(client);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	@Override
	public ClientMorale select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from User where code="+code);
		ClientMorale client=(ClientMorale)q.uniqueResult();
		t.commit();
		return client;
	}
	@Override
	public List<ClientMorale> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from User");
		List<ClientMorale> clients=(List<ClientMorale>)q.list();
		t.commit();
		return clients;
	}
	@Override
	public boolean delete(int code) {
		try {
			Transaction t=session.beginTransaction();
			Query q=session.createQuery("from User where code="+code);
			ClientMorale client=(ClientMorale)q.uniqueResult();
			session.delete(client);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
	}
	@Override
	public ClientMorale select(String key, String value) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from User where "+key+"="+value);
		ClientMorale client=(ClientMorale)q.uniqueResult();
		t.commit();
		return client;
	}

	
}
