package com.pfa.dao;

import java.util.List;

import com.pfa.jpa.ClientPhysique;

public interface ClientPhysiqueDao {
	public boolean insert(ClientPhysique client);
	public boolean update(ClientPhysique client);
	public ClientPhysique select(int code);
	public ClientPhysique select(String key,String value);
	public List<ClientPhysique> selectAll();
	public boolean delete(int code);
}
