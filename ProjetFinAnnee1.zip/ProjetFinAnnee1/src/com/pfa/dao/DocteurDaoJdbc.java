package com.pfa.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.pfa.jpa.Bilan;
import com.pfa.jpa.Docteur;

public class DocteurDaoJdbc implements DocteurDao{

	private Session session;
	
	public DocteurDaoJdbc(Session session) {
		this.session = session;
	}
	
	public DocteurDaoJdbc() {
	}
	
	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	@Override
	public boolean insert(Docteur doc) {
		
		try {
			Transaction t=session.beginTransaction();
			session.persist(doc);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
	}

	@Override
	public boolean update(Docteur doc) {
		
   	  	try {
			Transaction t=session.beginTransaction();
			session.update(doc);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
   	  	
   	  	
		
	}

	@Override
	public Docteur select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from User where user_code= :code");
		q.setString("code",""+code);
		Docteur doc=(Docteur)q.uniqueResult();
		t.commit();
		return doc;
	}

	@Override
	public Docteur select(String key, String value) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from User where "+key+"="+value);
		Docteur docteur=(Docteur)q.uniqueResult();
		t.commit();
		return docteur;
	}

	@Override
	public ArrayList<Docteur> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from User where DTYPE='Docteur'");
		ArrayList<Docteur> list=(ArrayList<Docteur>)q.list();
		t.commit();
		return list;
	}

	@Override
	public boolean delete(int code) {
		try {
			Transaction t=session.beginTransaction();
			Docteur docteur=select(code);
			session.delete(docteur);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}

	
}
