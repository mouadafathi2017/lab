package com.pfa.dao;

import java.util.List;

import com.pfa.jpa.RendezVous;

public interface RendezVousDao {
	public boolean insert(RendezVous rdv);
	public boolean update(RendezVous rdv);
	public RendezVous select(int code);
	public List<RendezVous> selectAll();
	public List<RendezVous> selectAll(int code_client);
	public boolean delete(int code);
}
