package com.pfa.dao;

import java.util.List;

import com.pfa.jpa.Bilan;

public interface BilanDao {
	public boolean insert(Bilan bilan);
	public boolean update(Bilan bilan);
	public Bilan select(int bilan_id);
	public List<Bilan> selectAll();
	public boolean delete(int bilan_id);
}
