package com.pfa.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.pfa.jpa.Bilan;
import com.pfa.jpa.Paiment;

public class PaimentDaoJdbc implements PaimentDao{

	private Session session;
	
	public PaimentDaoJdbc()
	{
	}
	public PaimentDaoJdbc(Session session) {
		this.session = session;
	}
	public Session getSession() {
		return session;
	}
	public void setSession(Session session) {
		this.session = session;
	}
	
	@Override
	public boolean insert(Paiment p) {
		
		try {
			Transaction t=session.beginTransaction();
			session.persist(p);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
	}

	@Override
	public boolean update(Paiment p) {
		
   	  	try {
			Transaction t=session.beginTransaction();
			session.update(p);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
   	  	
   	  	
	}

	@Override
	public Paiment select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Paiment where code= :code");
		q.setString("code",""+code);
		Paiment paiment=(Paiment)q.uniqueResult();
		t.commit();
		return paiment;
	}

	@Override
	public List<Paiment> select(String key, String value) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Paiment where "+key+"="+value);
		ArrayList<Paiment> list=(ArrayList<Paiment>)q.list();
		t.commit();
		return list;
	}

	@Override
	public ArrayList<Paiment> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Paiment");
		ArrayList<Paiment> list=(ArrayList<Paiment>)q.list();
		t.commit();
		return list;
	}
	@Override
	public boolean delete(int code) {
		try {
			Transaction t=session.beginTransaction();
			Paiment paiment=select(code);
			session.delete(paiment);
			t.commit();
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
			return false;
			
		}
		
	}

	
}
