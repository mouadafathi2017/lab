package com.pfa.test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.pfa.business.DefaultOfficeServices;
import com.pfa.dao.AnalyseDao;
import com.pfa.dao.AnalyseDaoJdbc;
import com.pfa.dao.BilanDao;
import com.pfa.dao.BilanDaoJdbc;
import com.pfa.dao.ClientMoraleDao;
import com.pfa.dao.ClientMoraleDaoJdbc;
import com.pfa.dao.ClientPhysiqueDao;
import com.pfa.dao.ClientPhysiqueDaoJdbc;
import com.pfa.dao.CompteDao;
import com.pfa.dao.CompteDaoJdbc;
import com.pfa.dao.DocteurDao;
import com.pfa.dao.DocteurDaoJdbc;
import com.pfa.dao.RendezVousDao;
import com.pfa.dao.RendezVousDaoJdbc;
import com.pfa.dao.SecretaireDao;
import com.pfa.dao.SecretaireDaoJdbc;
import com.pfa.jpa.Analyse;
import com.pfa.jpa.Bilan;
import com.pfa.jpa.Client;
import com.pfa.jpa.ClientMorale;
import com.pfa.jpa.ClientPhysique;
import com.pfa.jpa.Compte;
import com.pfa.jpa.Docteur;
import com.pfa.jpa.RendezVous;
import com.pfa.jpa.Secretaire;
import com.pfa.jpa.User;
import com.pfa.utils.HibernateUtils;

public class Main {
	private static Session s = null;
	
	public Main(){
		// Ouverture d'une session Hibernate
        this.s = HibernateUtils.getSession();
        
        ex01();
        s.close();
	}
	
	public void ex01(){

        Transaction t=s.beginTransaction();
        
        Compte c=new Compte("otmane","open","2015-04-25","2015-04-25","ClientPhysique",false);
        Bilan b =new Bilan();
        
        ClientMorale cl=new ClientMorale("otmane.ansarigmail.com", "0634692564", "FES", c, "Maroc",b,"ansari","43 rue oma benjelloun");
        b.setClient(cl);
        RendezVous rdv=new RendezVous("2015-005-01", false,cl);
        cl.setRDV(new LinkedList<RendezVous>());
        cl.getRDV().add(rdv);
        s.persist(cl);
        t.commit();
	}
	
	public void ex02(){
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Analyse analyse=new Analyse("Cliche de dos ",200,"Radiographie",1,null,sdf.format(new Date()),false,null,null);
		Compte c=new Compte("otmane","open","2015-04-25","2015-04-25","ClientPhysique",false);
		ClientMorale cl=new ClientMorale("otmane.ansarigmail.com", "0634692564", "FES", c, "Maroc",null,"ansari","43 rue oma benjelloun");
		ArrayList<Analyse> list =new ArrayList<>();
		list.add(analyse);
		Bilan b=new Bilan(cl,list);
		analyse.setBilan(b);
		cl.setBilan(b);
		s.persist(cl);
		AnalyseDao analyseDao=new AnalyseDaoJdbc(s);
		analyseDao.insert(analyse);
		
		list =(ArrayList<Analyse>)analyseDao.selectAll();
		for(Analyse a:list){
			System.out.println(a.toString());
			System.out.println(a.getBilan().getAnalyses().get(0).getNom());
		}
	}
	public void ex03(){
		Transaction t=s.beginTransaction();
		Compte c=new Compte("mouad","kingflow","2015-04-25","2015-04-25","ClientPhysique",false);
		User cl=new ClientPhysique("mouad.afathi@gmail.com", "0654367588", "Sefrou", c, "Maroc", null, "CD542655", "Afathi", "Mouad", "40 rue Sefrou", "1994-06-26");
		Bilan b=new Bilan();
		b.setClient((Client)cl);
		((Client)cl).setBilan(b);
		
		s.persist(cl);
		t.commit();
		
	}
	public void ex04(){
		Transaction t=s.beginTransaction();
		BilanDao bdao=new BilanDaoJdbc(s);
		bdao.delete(4);
		t.commit();
		
	}
	public void ex05(){
		//Transaction t=s.beginTransaction();
		ClientMoraleDao cldao=new ClientMoraleDaoJdbc(s);
		Client cl=cldao.select(1);
		System.out.println(cl.getBilan().getAnalyses().get(0).getNom());
		//t.commit();
	}
	public void ex06(){
		
		ClientMoraleDao cldao=new ClientMoraleDaoJdbc(s);
		ClientMorale cl=cldao.select(1);
		cl.getCompte().setDate_dernier_acces(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
		cldao.update(cl);
	}
	public void ex07(){
		ClientPhysiqueDao cldao=new ClientPhysiqueDaoJdbc(s);
		ClientPhysique cl=cldao.select(3);
		cl.getCompte().setDate_dernier_acces(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
		cldao.update(cl);
	}
	public void ex08(){
		ClientPhysiqueDao cldao=new ClientPhysiqueDaoJdbc(s);
		ClientPhysique cl=cldao.select(1);
		RendezVous rdv=new RendezVous(new SimpleDateFormat("yyyy-MM-dd").format(new Date()), false, cl);
		ArrayList<RendezVous> list=new ArrayList<RendezVous>();
		list.add(rdv);
		cl.setRDV(list);
		cldao.update(cl);
	}
	public void ex09(){
		ClientPhysiqueDao cldao=new ClientPhysiqueDaoJdbc(s);
		ClientPhysique cl=cldao.select(1);
		
		List<RendezVous> list=(List<RendezVous>)cl.getRDV();
		for(RendezVous rdv : list) System.out.println(rdv.toString());
		
	}
	public void ex10(){
		ClientPhysiqueDao cldao=new ClientPhysiqueDaoJdbc(s);
		ClientPhysique cl=cldao.select(1);
		Bilan bilan=cl.getBilan();
		Compte compte=new Compte("otmane_ansari","opensimsim","2015-01-02","2015-04-29","Docteur",true);
		
		Docteur doc=new Docteur("otmane.ansari@usmba.ac.ma", "0634692564", "FES", compte, "Ansari", "Othmane", "CD379763", "C445632", "43 rue 16 novembre", 0, 20000, "2011-05-01","Celib","cardiologue",1000,null);
		
		Analyse analyse=new Analyse("analyse des poumons", 700,"analyse du sang",7,null,new SimpleDateFormat("yyyy-MM-dd").format(new Date()),false, bilan, doc);
		List<Analyse> list=new ArrayList<Analyse>();
		list.add(analyse);
		doc.setAnalyses(list);
		bilan.setAnalyses(list);
		DocteurDao docdao=new DocteurDaoJdbc(s);
		docdao.insert(doc);
		cldao.update(cl);
		
	}
	public void ex11(){
		
		ClientPhysiqueDao cldao=new ClientPhysiqueDaoJdbc(s);
		DefaultOfficeServices office=new DefaultOfficeServices();
		office.setClientphysiquedao(cldao);
		Compte c=new Compte("otmane","open",new SimpleDateFormat("yyyy-MM-dd").format(new Date()),new SimpleDateFormat("yyyy-MM-dd").format(new Date()),"ClientPhysique",false);
		Bilan bilan=new Bilan();
		ClientPhysique cl=new ClientPhysique("otmane.ansari@usmba.ac.ma", "0634692564", "Fes", c, "Maroc", bilan, "CD379763", "Ansari", "Othmane", "43 rue 16 novembre","1994-04-04");
		
		office.nouveau_clientPhysique(cl);
		
	}
	public void ex12(){
		ClientPhysiqueDao cldao=new ClientPhysiqueDaoJdbc(s);
		RendezVousDao rdvdao=new RendezVousDaoJdbc(s);
		ClientPhysique cl=cldao.select(6);
		RendezVous rdv=new RendezVous("2015-05-20", false, cl);
		DefaultOfficeServices office=new DefaultOfficeServices();
		office.setRendezvousdao(rdvdao);
		office.demanderRdv(rdv);
		
		
	}
	public void ex13(){
		CompteDao comptedao=new CompteDaoJdbc(s);
		Compte compte=comptedao.select("otmane", "open");
		System.out.println(compte);
	}
	public void ex14(){
		RendezVousDao rdvdao=new RendezVousDaoJdbc(s);
		List<RendezVous> list=rdvdao.selectAll(1);
		for(RendezVous rdv:list)System.out.println(rdv);
	}
	public void ex15(){
		RendezVousDao rdvdao=new RendezVousDaoJdbc(s);
		ClientPhysiqueDao cldao=new ClientPhysiqueDaoJdbc(s);
		//cldao.delete(9);
		rdvdao.delete(2);
	}
	
	public void ex16(){
		RendezVousDao rdvdao=new RendezVousDaoJdbc(s);
		DefaultOfficeServices office=new DefaultOfficeServices();
		office.setRendezvousdao(rdvdao);
		System.out.println(office.listRdvToday());
	}
	public void ex17(){
		RendezVousDao rdvdao=new RendezVousDaoJdbc(s);
		DefaultOfficeServices office=new DefaultOfficeServices();
		office.setRendezvousdao(rdvdao);
		System.out.println(office.listRdvNV());
	}
	public void ex18(){
		DocteurDao docdao=new DocteurDaoJdbc(s);
		
		System.out.println(docdao.select("user_compteID",""+2).toString());
	}
	public void ex19(){
		SecretaireDao secdao=new SecretaireDaoJdbc(s);
		Compte c=new Compte("secretaire","opens",new SimpleDateFormat("yyyy-MM-dd").format(new Date()),new SimpleDateFormat("yyyy-MM-dd").format(new Date()),"Secretaire",true);
		Secretaire s=new Secretaire("polysecretaire@gmail.com", "0645324788", "FES", c,"alaoui","sarra","CD547689","C456337","rue agdal",0,3000,new SimpleDateFormat("yyyy-MM-dd").format(new Date()),"Celib",2);
		secdao.insert(s);
	}
	public void ex20(){
		String s="/volum/otmane ansari/upload";
		System.out.println(s);
		s=s.replace(" ", "\\ ");
		System.out.println(s);
	}
	public static void main(String[] args) {
		
        new Main();
        
	}

}
