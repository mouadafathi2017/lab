package com.pfa.test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;

import com.pfa.dao.ClientPhysiqueDao;
import com.pfa.dao.ClientPhysiqueDaoJdbc;
import com.pfa.dao.DocteurDao;
import com.pfa.dao.DocteurDaoJdbc;
import com.pfa.dao.SecretaireDao;
import com.pfa.dao.SecretaireDaoJdbc;
import com.pfa.jpa.Analyse;
import com.pfa.jpa.Bilan;
import com.pfa.jpa.ClientPhysique;
import com.pfa.jpa.Compte;
import com.pfa.jpa.Docteur;
import com.pfa.jpa.Secretaire;
import com.pfa.utils.HibernateUtils;

public class Main2 {

	public static void main(String[] args) {
		
		Session s = null;
		s = HibernateUtils.getSession();
		Compte compte=new Compte("docteur","opendoc","2015-01-02","2015-04-29","Docteur",true);
		
		Docteur doc=new Docteur("mouad.afathi@gmail.com", "0645878386", "Sefrou", compte, "Afathi", "Mouad", "CD379763", "C445632", "218 BLOC 4 RACHAD", 0, 20000, "2011-05-01","Celib","cardiologue",1000,null);
		DocteurDao docdao=new DocteurDaoJdbc(s);
		boolean ins = docdao.insert(doc);
		System.out.println(ins);

	}

}
