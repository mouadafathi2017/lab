package com.pfa.jpa;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="Paiment")
public class Paiment {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="code")
	private int code;
	@Column(name="typeCarte")
	private String typeCarte;
	@Column(name="numeroCarte")
	private String numeroCarte;
	@Column(name="dateExpiration")
	private Date dateExpiration;
	@Column(name="code_securite")
	private String code_securite;
	@Column(name="montant")
	private float montant;
	public Paiment() {
	}
	public Paiment(int code, String typeCarte, String numeroCarte,
			Date dateExpiration, String code_securite, float montant) {
		this.code = code;
		this.typeCarte = typeCarte;
		this.numeroCarte = numeroCarte;
		this.dateExpiration = dateExpiration;
		this.code_securite = code_securite;
		this.montant = montant;
		
	}
	
	public Paiment(String typeCarte, String numeroCarte, Date dateExpiration,
			String code_securite, float montant) {
		super();
		this.typeCarte = typeCarte;
		this.numeroCarte = numeroCarte;
		this.dateExpiration = dateExpiration;
		this.code_securite = code_securite;
		this.montant = montant;
		
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getTypeCarte() {
		return typeCarte;
	}
	public void setTypeCarte(String typeCarte) {
		this.typeCarte = typeCarte;
	}
	public String getNumeroCarte() {
		return numeroCarte;
	}
	public void setNumeroCarte(String numeroCarte) {
		this.numeroCarte = numeroCarte;
	}
	public Date getDateExpiration() {
		return dateExpiration;
	}
	public void setDateExpiration(Date dateExpiration) {
		this.dateExpiration = dateExpiration;
	}
	public String getCode_securite() {
		return code_securite;
	}
	public void setCode_securite(String code_securite) {
		this.code_securite = code_securite;
	}
	public float getMontant() {
		return montant;
	}
	public void setMontant(float montant) {
		this.montant = montant;
	}

	
}
