package com.pfa.jpa;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
@Entity
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@Table(name="client_morale")
public class ClientMorale extends Client{
	@Column(name="nom")
	private String nom;
	@Column(name="adresse")
	private String adresse;
	public ClientMorale() {
		super();
	}
	
	public ClientMorale(String pays, List<RendezVous> rDV,
			Bilan bilan, int code, String email, String telephone,
			String ville, Compte compte, String nom, String adresse) {
		super(pays, rDV, bilan, code, email, telephone, ville, compte);
		this.nom = nom;
		this.adresse = adresse;
	}

	public ClientMorale(String email, String telephone, String ville,
			Compte compte, String pays, Bilan bilan, String nom, String adresse) {
		super(email, telephone, ville, compte, pays, bilan);
		this.nom = nom;
		this.adresse = adresse;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	
}
