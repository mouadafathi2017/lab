package com.pfa.jpa;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@Table(name="Secretaire")
public class Secretaire extends Personnel{
	@Column(name="niveau")
	private int niveau;
	@Column(name="tauxPrime")
	private final float tauxPrime=200*niveau;
	
	
	public Secretaire() {
	}
	
	public Secretaire(int niveau) {
		this.niveau = niveau;
		
	}
	

	public Secretaire(String email, String telephone, String ville,
			Compte compte, String nom, String prenom, String cin,
			String numero_securite_social, String adresse, int nbr_enfants,
			float saliare_basse, String dateRecrutement,
			String situationFamiliale,int niveau) {
		super(email, telephone, ville, compte, nom, prenom, cin,
				numero_securite_social, adresse, nbr_enfants, saliare_basse,
				dateRecrutement, situationFamiliale);
		this.niveau = niveau;
		// TODO Auto-generated constructor stub
	}

	public int getNiveau() {
		return niveau;
	}
	public void setNiveau(int niveau) {
		this.niveau = niveau;
	}
	public float getTauxPrime() {
		return tauxPrime;
	}
	
	
	
}
