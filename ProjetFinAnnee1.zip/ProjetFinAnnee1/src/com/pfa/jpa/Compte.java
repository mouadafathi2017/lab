package com.pfa.jpa;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="compte")
public class Compte {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="code_compte")
	private int code;
	@Column(name="login")
	private String login;
	@Column(name="password")
	private String password;
	@Column(name="dateCreation")
	private String dateCreation;
	@Column(name="date_dernier_acces")
	private String date_dernier_acces;
	@Column(name="type")
	private String type;
	@Column(name="active")
	private boolean active;
	
	public Compte() {
	}
	
	public Compte(String login, String password, String dateCreation,
			String date_dernier_acces,String type, boolean active) {
		super();
		this.login = login;
		this.password = password;
		this.dateCreation = dateCreation;
		this.date_dernier_acces = date_dernier_acces;
		this.type = type;
		this.active = active;
	}

	public Compte(int code, String login, String password, String dateCreation,
			String date_dernier_acces,String type, boolean active) {
		super();
		this.code = code;
		this.login = login;
		this.password = password;
		this.dateCreation = dateCreation;
		this.date_dernier_acces = date_dernier_acces;
		this.type = type;
		this.active = active;
	}

	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDateCreation() {
		return dateCreation;
	}
	public void setDateCreation(String dateCreation) {
		this.dateCreation = dateCreation;
	}
	public String getDate_dernier_acces() {
		return date_dernier_acces;
	}
	public void setDate_dernier_acces(String date_dernier_acces) {
		this.date_dernier_acces = date_dernier_acces;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "Compte [code=" + code + ", login=" + login + ", password="
				+ password + ", dateCreation=" + dateCreation
				+ ", date_dernier_acces=" + date_dernier_acces + ", type="
				+ type + ", active=" + active + "]";
	}
	
}
