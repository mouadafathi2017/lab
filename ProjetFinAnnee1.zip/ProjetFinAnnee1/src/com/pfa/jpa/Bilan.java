package com.pfa.jpa;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="Bilan")
public class Bilan {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="bilan_id")
	private int id;
	@OneToOne(mappedBy="bilan")
	@JoinColumn(name="bilan_clientID",referencedColumnName="user_code")
	private Client client;
	@OneToMany(cascade={CascadeType.ALL},mappedBy="bilan")
	private List<Analyse> analyses;
	
	public Bilan() {
	}
	public Bilan(Client client, List<Analyse> analyses) {
		this.client = client;
		this.analyses = analyses;
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public List<Analyse> getAnalyses() {
		return analyses;
	}
	public void setAnalyses(List<Analyse> analyses) {
		this.analyses = analyses;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Bilan [id=" + id + ", client=" + client + ", analyses="
				+ analyses.toArray()[0] + "]";
	}
	
}
