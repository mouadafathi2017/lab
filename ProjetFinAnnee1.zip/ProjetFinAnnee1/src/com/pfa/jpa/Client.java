package com.pfa.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@Table(name="client")
public class Client extends User{
	
	
	@Column(name="client_pays")
	private String pays;

	@OneToMany(mappedBy="client",cascade={CascadeType.ALL})
	@Column(name="rdv")
	private List<RendezVous> RDV;
	
	@OneToOne(cascade={CascadeType.ALL})
	private Bilan bilan;
	public Client() {
		super();
	}
	public Client(String pays,List<RendezVous> rDV, Bilan bilan,int code, String email, String telephone, String ville,
			Compte compte) {
		super(code,email,telephone,ville,compte);
		this.pays = pays;
		
		RDV = rDV;
		this.bilan = bilan;
	}
	
	public Client( String email, String telephone, String ville,
			Compte compte, String pays, Bilan bilan) {
		super(email, telephone, ville, compte);
		this.pays = pays;
		this.bilan = bilan;
	}
	public String getPays() {
		return pays;
	}
	public void setPays(String pays) {
		this.pays = pays;
	}

	public List<RendezVous> getRDV() {
		return RDV;
	}
	public void setRDV(List<RendezVous> rDV) {
		RDV = rDV;
	}
	public Bilan getBilan() {
		return bilan;
	}
	public void setBilan(Bilan bilan) {
		this.bilan = bilan;
	}
	
	
}
