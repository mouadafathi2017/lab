package com.pfa.jpa;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="user")
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="user_code")
	private int code;
	@Column(name="email")
	private String email;
	@Column(name="telephone")
	private String telephone;
	@Column(name="ville")
	private String ville;
	@OneToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="user_compteID",referencedColumnName="code_compte")
	private Compte compte;
	public User() {
	}
	public User(int code, String email, String telephone, String ville,
			Compte compte) {
		this.code = code;
		this.email = email;
		this.telephone = telephone;
		this.ville = ville;
		this.compte = compte;
	}
	
	public User( String email, String telephone, String ville,
			Compte compte) {
		super();
		
		this.email = email;
		this.telephone = telephone;
		this.ville = ville;
		this.compte = compte;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getVille() {
		return ville;
	}
	public void setVille(String ville) {
		this.ville = ville;
	}
	public Compte getCompte() {
		return compte;
	}
	public void setCompte(Compte compte) {
		this.compte = compte;
	}
	
	
}
