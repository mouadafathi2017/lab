package com.pfa.jpa;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="rendez_vous")
public class RendezVous {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="RendezVous_code")
	private int code;
	@Column(name="date")
	private String date;
	@Column(name="active")
	private boolean active;
	@ManyToOne()
	@JoinColumn(name="rdv_client_id")
	private Client client;
	public RendezVous() {
	}
	public RendezVous(int code, String date, boolean active) {
		this.code = code;
		this.date = date;
		this.active = active;
	}
	
	public RendezVous(int code, String date, boolean active, Client client) {
		super();
		this.code = code;
		this.date = date;
		this.active = active;
		this.client = client;
	}
	public RendezVous(String date, boolean active, Client client) {
		super();
		this.date = date;
		this.active = active;
		this.client = client;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	@Override
	public String toString() {
		return "RendezVous [code=" + code + ", date=" + date + ", active="
				+ active + "]";
	}
	
}
