package com.pfa.jpa;

import java.util.Date;
import java.util.List;

public class Administrateur {

	private int id;
	private String login;
	private String password;
	private Date dateCreation;
	private Date dernierAcces;
	
	public Administrateur() {
	}
	public Administrateur(int id, String login, String password,
			Date dateCreation, Date dernierAcces) {
		this.id = id;
		this.login = login;
		this.password = password;
		this.dateCreation = dateCreation;
		this.dernierAcces = dernierAcces;
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Date getDateCreation() {
		return dateCreation;
	}
	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
	}
	public Date getDernierAcces() {
		return dernierAcces;
	}
	public void setDernierAcces(Date dernierAcces) {
		this.dernierAcces = dernierAcces;
	}

	
}
