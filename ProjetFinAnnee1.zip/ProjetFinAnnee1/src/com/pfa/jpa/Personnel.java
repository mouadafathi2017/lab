package com.pfa.jpa;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
@Entity
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@Table(name="PersonnelO")
public class Personnel extends User {
	@Column(name="nom")
	private String nom;
	@Column(name="prenom")
	private String prenom;
	@Column(name="cin")
	private String cin;
	@Column(name="numero_securite_social")
	private String numero_securite_social;
	@Column(name="adresse")
	private String adresse;
	@Column(name="nbr_enfants")
	private int nbr_enfants;
	@Column(name="salaire_basse")
	private float saliare_basse;
	@Column(name="dateRecrutement")
	private String dateRecrutement;
	@Column(name="situationFamiliale")
	private String situationFamiliale;
	
	public Personnel() {
		super();
	}
	public Personnel(int code, String email, String telephone, String ville,
			 String nom, String prenom, String cin,
			String numero_securite_social, String adresse, int nbr_enfants,
			float saliare_basse, String dateRecrutement,
			String situationFamiliale, Compte comptePersonnel) {
		super(code, email, telephone, ville,comptePersonnel);
		this.nom = nom;
		this.prenom = prenom;
		this.cin = cin;
		this.numero_securite_social = numero_securite_social;
		this.adresse = adresse;
		this.nbr_enfants = nbr_enfants;
		this.saliare_basse = saliare_basse;
		this.dateRecrutement = dateRecrutement;
		this.situationFamiliale = situationFamiliale;
		
	}
	
	public Personnel(String email, String telephone, String ville,
			Compte compte, String nom, String prenom, String cin,
			String numero_securite_social, String adresse, int nbr_enfants,
			float saliare_basse, String dateRecrutement, String situationFamiliale) {
		super(email, telephone, ville, compte);
		this.nom = nom;
		this.prenom = prenom;
		this.cin = cin;
		this.numero_securite_social = numero_securite_social;
		this.adresse = adresse;
		this.nbr_enfants = nbr_enfants;
		this.saliare_basse = saliare_basse;
		this.dateRecrutement = dateRecrutement;
		this.situationFamiliale = situationFamiliale;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getCin() {
		return cin;
	}
	public void setCin(String cin) {
		this.cin = cin;
	}
	public String getNumero_securite_social() {
		return numero_securite_social;
	}
	public void setNumero_securite_social(String numero_securite_social) {
		this.numero_securite_social = numero_securite_social;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public int getNbr_enfants() {
		return nbr_enfants;
	}
	public void setNbr_enfants(int nbr_enfants) {
		this.nbr_enfants = nbr_enfants;
	}
	public float getSaliare_basse() {
		return saliare_basse;
	}
	public void setSaliare_basse(float saliare_basse) {
		this.saliare_basse = saliare_basse;
	}
	public String getDateRecrutement() {
		return dateRecrutement;
	}
	public void setDateRecrutement(String dateRecrutement) {
		this.dateRecrutement = dateRecrutement;
	}
	public String getSituationFamiliale() {
		return situationFamiliale;
	}
	public void setSituationFamiliale(String situationFamiliale) {
		this.situationFamiliale = situationFamiliale;
	}

	
}
