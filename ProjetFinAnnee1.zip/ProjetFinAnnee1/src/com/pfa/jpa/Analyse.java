package com.pfa.jpa;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="analyse")
public class Analyse {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="code")
	private int code;
	@Column(name="nom")
	private String nom;
	@Column(name="prix")
	private float prix;
	@Column(name="type")
	private String type;
	@Column(name="duree")
	private int duree;
	@OneToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="analyse_resultatID",referencedColumnName="code_resultatAnalyse")
	private ResultatAnalyse ResAnalyse;
	private String dateAnalyse;
	@Column(name="paid")
	private boolean paid;
	@ManyToOne
	@JoinColumn(name="analyse_bilanID")
	private Bilan bilan;
	@ManyToOne
	@JoinColumn(name="analyse_docteurID")
	private Docteur docteur;
	public Analyse() {
	}
	public Analyse(int code, String nom, float prix, String type, int duree,
			ResultatAnalyse resAnalyse, String dateAnalyse,
			Secretaire secretaire, boolean paid,Docteur docteur) {
		this.code = code;
		this.nom = nom;
		this.prix = prix;
		this.type = type;
		this.duree = duree;
		ResAnalyse = resAnalyse;
		this.dateAnalyse = dateAnalyse;
		this.docteur=docteur;
		this.paid = paid;
	}
	
	
	
	public Analyse(String nom, float prix, String type, int duree,
			ResultatAnalyse resAnalyse, String dateAnalyse, boolean paid,
			Bilan bilan,Docteur docteur) {
		super();
		this.nom = nom;
		this.prix = prix;
		this.type = type;
		this.duree = duree;
		ResAnalyse = resAnalyse;
		this.dateAnalyse = dateAnalyse;
		this.paid = paid;
		this.bilan = bilan;
		this.docteur=docteur;
	}
	public Analyse(int code, String nom, float prix, String type, int duree,
			ResultatAnalyse resAnalyse, String dateAnalyse, boolean paid,
			Bilan bilan,Docteur docteur) {
		super();
		this.code = code;
		this.nom = nom;
		this.prix = prix;
		this.type = type;
		this.duree = duree;
		ResAnalyse = resAnalyse;
		this.dateAnalyse = dateAnalyse;
		this.paid = paid;
		this.bilan = bilan;
		this.docteur=docteur;
	}
	
	public Bilan getBilan() {
		return bilan;
	}
	public void setBilan(Bilan bilan) {
		this.bilan = bilan;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public float getPrix() {
		return prix;
	}
	public void setPrix(float prix) {
		this.prix = prix;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getDuree() {
		return duree;
	}
	public void setDuree(int duree) {
		this.duree = duree;
	}
	public ResultatAnalyse getResAnalyse() {
		return ResAnalyse;
	}
	public void setResAnalyse(ResultatAnalyse resAnalyse) {
		ResAnalyse = resAnalyse;
	}
	public String getDateAnalyse() {
		return dateAnalyse;
	}
	public void setDateAnalyse(String dateAnalyse) {
		this.dateAnalyse = dateAnalyse;
	}
	
	public boolean isPaid() {
		return paid;
	}
	public void setPaid(boolean paid) {
		this.paid = paid;
	}
	@Override
	public String toString() {
		return "Analyse [code=" + code + ", nom=" + nom + ", prix=" + prix
				+ ", type=" + type + ", duree=" + duree  + ", dateAnalyse=" + dateAnalyse + ", paid="
				+ paid + ", bilan=" + bilan.getId()  + "]";
	}
	
	
	
}
