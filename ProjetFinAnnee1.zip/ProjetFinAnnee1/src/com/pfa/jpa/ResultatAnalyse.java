package com.pfa.jpa;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="ResultatAnalyse")
public class ResultatAnalyse {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="code_resultatAnalyse")
	private int code;
	@Column(name="dateDepot")
	private String dateDepot;
	@Column(name="titre")
	private String titre;
	@Column(name="lien")
	private String lien;
	public ResultatAnalyse() {
	}
	public ResultatAnalyse(int code, String dateDepot, String titre, String lien) {
		this.code = code;
		this.dateDepot = dateDepot;
		this.titre = titre;
		this.lien = lien;
	}
	
	public ResultatAnalyse(String dateDepot, String titre, String lien) {
		super();
		this.dateDepot = dateDepot;
		this.titre = titre;
		this.lien = lien;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getDateDepot() {
		return dateDepot;
	}
	public void setDateDepot(String dateDepot) {
		this.dateDepot = dateDepot;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public String getLien() {
		return lien;
	}
	public void setLien(String lien) {
		this.lien = lien;
	}
	
}
