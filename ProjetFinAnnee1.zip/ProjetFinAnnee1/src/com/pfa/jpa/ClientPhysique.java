package com.pfa.jpa;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
@Entity
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@Table(name="client_physique")
public class ClientPhysique extends Client{
	@Column(name="cin")
	private String cin;
	@Column(name="nom")
	private String nom;
	@Column(name="prenom")
	private String prenom;
	@Column(name="adresse")
	private String adresse;
	@Column(name="date_naissance")
	private String date_naissance;
	public ClientPhysique() {
		super();
	}
	public ClientPhysique(String pays, List<RendezVous> rDV,
			Bilan bilan, int code, String email, String telephone,
			String ville, Compte compte, String cin, String nom, String prenom,
			String adresse, String date_naissance) {
		super(pays, rDV, bilan, code, email, telephone, ville, compte);
		this.cin = cin;
		this.nom = nom;
		this.prenom = prenom;
		this.adresse = adresse;
		this.date_naissance = date_naissance;
	}
	
	public ClientPhysique(String email, String telephone, String ville,
			Compte compte, String pays, Bilan bilan, String cin, String nom,
			String prenom, String adresse, String date_naissance) {
		super(email, telephone, ville, compte, pays, bilan);
		this.cin = cin;
		this.nom = nom;
		this.prenom = prenom;
		this.adresse = adresse;
		this.date_naissance = date_naissance;
	}
	public String getCin() {
		return cin;
	}
	public void setCin(String cin) {
		this.cin = cin;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public String getDate_naissance() {
		return date_naissance;
	}
	public void setDate_naissance(String date_naissance) {
		this.date_naissance = date_naissance;
	}
	@Override
	public String toString() {
		return "ClientPhysique [cin=" + cin + ", nom=" + nom + ", prenom="
				+ prenom + ", adresse=" + adresse + ", date_naissance="
				+ date_naissance +"compte: "+getCompte()+ "]";
	}
	
	
}
