package com.pfa.jpa;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@Table(name="Docteur")
public class Docteur extends Personnel{
	@Column(name="domaine")
	private String domaine;
	@Column(name="tauxPrime")
	private float tauxPrime;
	@OneToMany(cascade={CascadeType.ALL},mappedBy="docteur")
	private List<Analyse> analyses;
	public Docteur() {
	}
	
	
	public Docteur(String email, String telephone, String ville, Compte compte,
			String nom, String prenom, String cin,
			String numero_securite_social, String adresse, int nbr_enfants,
			float saliare_basse, String dateRecrutement,
			String situationFamiliale, String domaine, float tauxPrime,
			List<Analyse> analyses) {
		super(email, telephone, ville, compte, nom, prenom, cin,
				numero_securite_social, adresse, nbr_enfants, saliare_basse,
				dateRecrutement, situationFamiliale);
		this.domaine = domaine;
		this.tauxPrime = tauxPrime;
		this.analyses = analyses;
	}


	public Docteur(int code, String email, String telephone, String ville,
			String nom, String prenom, String cin,
			String numero_securite_social, String adresse, int nbr_enfants,
			float saliare_basse, String dateRecrutement,
			String situationFamiliale, Compte comptePersonnel, String domaine,
			float tauxPrime, List<Analyse> analyses) {
		super(code, email, telephone, ville, nom, prenom, cin,
				numero_securite_social, adresse, nbr_enfants, saliare_basse,
				dateRecrutement, situationFamiliale, comptePersonnel);
		this.domaine = domaine;
		this.tauxPrime = tauxPrime;
		this.analyses = analyses;
	}


	public String getDomaine() {
		return domaine;
	}
	public void setDomaine(String domaine) {
		this.domaine = domaine;
	}
	public float getTauxPrime() {
		return tauxPrime;
	}
	public void setTauxPrime(float tauxPrime) {
		this.tauxPrime = tauxPrime;
	}
	public List<Analyse> getAnalyses() {
		return analyses;
	}
	public void setAnalyses(List<Analyse> analyses) {
		this.analyses = analyses;
	}


	@Override
	public String toString() {
		return "Docteur [domaine=" + domaine + ", tauxPrime=" + tauxPrime
				+ ", analyses=" + analyses + "]";
	}
	
}
