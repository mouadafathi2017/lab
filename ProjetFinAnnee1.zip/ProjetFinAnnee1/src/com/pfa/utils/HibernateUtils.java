package com.pfa.utils;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
 
public class HibernateUtils {
    private static final SessionFactory sessionFactory;
 
    // Crée une unique instance de la SessionFactory à partir de hibernate.cfg.xml
    static {
        try {
            sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
        } catch (HibernateException ex) {
        	for (int i = 0; i < ex.getStackTrace().length; i++) {
				System.out.println(ex.getStackTrace()[i].getFileName()+"   "+ex.getStackTrace()[i].getMethodName()+"     "+ex.getStackTrace()[i].getLineNumber());
			}
            throw new RuntimeException("Problème de configuration : " + ex.getMessage(), ex);
        }
    }
 
    // Renvoie une session Hibernate
    public static Session getSession() throws HibernateException {
        return sessionFactory.openSession();
    }
}