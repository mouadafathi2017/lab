package com.pfa.web;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;

import com.pfa.business.DefaultOfficeServices;
import com.pfa.business.OfficeServices;
import com.pfa.dao.AnalyseDao;
import com.pfa.dao.AnalyseDaoJdbc;
import com.pfa.dao.BilanDao;
import com.pfa.dao.BilanDaoJdbc;
import com.pfa.dao.ClientMoraleDao;
import com.pfa.dao.ClientMoraleDaoJdbc;
import com.pfa.dao.ClientPhysiqueDao;
import com.pfa.dao.ClientPhysiqueDaoJdbc;
import com.pfa.dao.CompteDao;
import com.pfa.dao.CompteDaoJdbc;
import com.pfa.dao.DocteurDao;
import com.pfa.dao.DocteurDaoJdbc;
import com.pfa.dao.RendezVousDao;
import com.pfa.dao.RendezVousDaoJdbc;
import com.pfa.dao.SecretaireDao;
import com.pfa.dao.SecretaireDaoJdbc;
import com.pfa.utils.HibernateUtils;
import com.pfa.web.actions.ClientAction;
import com.pfa.web.actions.DocteurAction;
import com.pfa.web.actions.MailAction;
import com.pfa.web.actions.SecretaireAction;
import com.pfa.web.actions.UserAction;

/**
 * Servlet implementation class Controleur
 */
public class Controleur extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Session session;
	private ClientPhysiqueDao clpdao;
	private ClientMoraleDao clmdao;
	private CompteDao comptedao;
	private RendezVousDao rdvdao;
	private AnalyseDao analdao;
	private DocteurDao docdao;
	private SecretaireDao secdao;
	private BilanDao bildao;
	private OfficeServices officeservices;
	private ClientAction claction;
	private UserAction useraction;
	private MailAction mailaction;
	private DocteurAction docaction;
	private SecretaireAction secaction;
	
	
	

	   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controleur() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		session=HibernateUtils.getSession();
		clpdao=new ClientPhysiqueDaoJdbc(session);
		clmdao=new ClientMoraleDaoJdbc(session);
		comptedao=new CompteDaoJdbc(session);
		rdvdao=new RendezVousDaoJdbc(session);
		analdao=new AnalyseDaoJdbc(session);
		docdao=new DocteurDaoJdbc(session);
		secdao=new SecretaireDaoJdbc(session);
		bildao=new BilanDaoJdbc(session);
		officeservices=new DefaultOfficeServices(bildao,secdao,docdao,analdao,rdvdao,clpdao,clmdao,comptedao);
		claction=new ClientAction(officeservices);
		useraction=new UserAction(officeservices);
		docaction=new DocteurAction(officeservices);
		secaction=new SecretaireAction(officeservices);
		mailaction=new MailAction(officeservices);
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String view="";
		String uri = request.getRequestURI();

		int i = uri.lastIndexOf('/') + 1;
		int j = uri.lastIndexOf('.');
		String key = uri.substring(i, j);
		
		
		
		System.out.println(uri);
		switch (key) {
		case "login":
			useraction.setRequest(request);
			System.out.println("catched by servlet !!");
			view=useraction.authentification();
			break;

		case "logout":
			request.getSession().invalidate();
			view="/views/index.jsp";
			break;
		case "newclient":
			
			claction.setRequest(request);
			if(request.getParameter("account").equals("Physique")){
				view=claction.nouveau_clientPhysique();
				
			}
			else {
				view=claction.nouveau_clientMorale();
			}
			break;
		case "rendezvous":
			claction.setRequest(request);
			view=claction.listerRdv();
			break;
		case "deleterdv":
			claction.setRequest(request);
			view=claction.supprimerRdv();
			break;
		case "modifyrdv":
			claction.setRequest(request);
			view=claction.recupererRdv();
			break;
		case "modify":
			claction.setRequest(request);
			view=claction.modifierRdv();
			break;
		case "demande":
			claction.setRequest(request);
			view=claction.demanderRdv();
			break;
		case "getprofile":
			claction.setRequest(request);
			request.setAttribute("user",claction.getUser());
			view="/views/profile.jsp";
			break;
		case "getprofileS":
			secaction.setRequest(request);
			request.setAttribute("user",secaction.getUser());
			view="/views/profileS.jsp";
			break;
		case "modifyprofile":
			claction.setRequest(request);
			view=claction.modifierProfile();
			break;
		case "modifyprofileS":
			secaction.setRequest(request);
			view=secaction.modifierProfile();
			break;
		case "analyses":
			claction.setRequest(request);
			view=claction.listerAnalyses();
			break;
		case "demandeinformation":
			mailaction.setRequest(request);System.out.println("email :"+request.getParameter("email"));
			mailaction.send();
			view="/views/index.jsp";
			break;
		case "listRdvDoc":
			docaction.setRequest(request);
			view=docaction.listerRdvDoc();
			break;	
		case "listRdvNV":
			secaction.setRequest(request);
			view=secaction.listRdvNV();
			break;
		case "rejectrdv":
			secaction.setRequest(request);
			view=secaction.rejeterRdv();
			break;
		case "confirmrdv":
			secaction.setRequest(request);
			view=secaction.validerRdv();
			break;
		case "FormulaireA":
			request.setAttribute("list_doc",docdao.selectAll());
			view="/views/FormulaireAnalyse.jsp";
			break; 
		case "addAnalyse":
			secaction.setRequest(request);
			view=secaction.ajouterAnalyse();
			break;
		case "insertRA":
			secaction.setRequest(request);
			view=secaction.listAnalyseSR();
			break;
		case "addRA":
			secaction.setRequest(request);System.out.println(request.getParameter("titre"));
			view=secaction.addRA();
			break;
		default:
			break;
		}
		request.getServletContext().getRequestDispatcher(view).forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
