package com.pfa.web.actions;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpSession;

import com.pfa.business.OfficeServices;
import com.pfa.jpa.User;

public class UserAction extends Action {

	public UserAction() {
		
	}

	public UserAction(OfficeServices officeServices) {
		super(officeServices);
		
	}

	public String authentification(){
		//System.out.println(getRequest().getParameter("login"));
		User user=getOfficeservices().authentification(getRequest().getParameter("login"), getRequest().getParameter("password"));
		if(user!=null){
			if (getRequest().getSession()!=null) {
				getRequest().getSession().invalidate();
			}
			HttpSession session = getRequest().getSession(true); 
			session.setAttribute("login",getRequest().getParameter("login"));
			session.setAttribute("password",getRequest().getParameter("password"));
			System.out.println("session créer");
			switch (user.getClass().getName()) {
			case "com.pfa.jpa.ClientPhysique":case"com.pfa.jpa.ClientMorale":{
				System.out.println(getRequest().getAttribute("type"));
				
					session.setAttribute("type","client");
					user.getCompte().setDate_dernier_acces(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
					getOfficeservices().modifierCompte(user.getCompte());
					getRequest().setAttribute("message", "Bonjour Monsieur,Madame");
					return "/views/clientVue.jsp";
				
			
			}
			case "com.pfa.jpa.Docteur":{
				System.out.println(getRequest().getAttribute("type"));
				session.setAttribute("type","docteur");
				user.getCompte().setDate_dernier_acces(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
				getOfficeservices().modifierCompte(user.getCompte());
				getRequest().setAttribute("message", "Bonjour Monsieur,Madame");
				return "/views/DocteurVue.jsp";
				
				
			}
			case "com.pfa.jpa.Secretaire":{
				
				session.setAttribute("type","secretaire");
				user.getCompte().setDate_dernier_acces(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
				getOfficeservices().modifierCompte(user.getCompte());
				getRequest().setAttribute("message", "Bonjour Monsieur,Madame");
				return "/views/SecretaireVue.jsp";
				
				
			}
			default:{
				getRequest().setAttribute("message", "Login ou mot de pass erroné");
				return "/views/Error.jsp";
			}
		}
		}	
		else{
			getRequest().setAttribute("message", "Login ou mot de pass erroné");
			return "/views/Error.jsp";
		}
	}
}
