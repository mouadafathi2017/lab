package com.pfa.web.actions;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


import com.pfa.business.OfficeServices;
import com.pfa.jpa.Analyse;
import com.pfa.jpa.Bilan;
import com.pfa.jpa.Client;
import com.pfa.jpa.ClientMorale;
import com.pfa.jpa.ClientPhysique;
import com.pfa.jpa.Compte;
import com.pfa.jpa.RendezVous;
import com.pfa.jpa.User;

public class ClientAction extends Action {

	public ClientAction() {
		// TODO Auto-generated constructor stub
	}

	public ClientAction(OfficeServices officeServices) {
		super(officeServices);
		
	}
	public String nouveau_clientPhysique(){
		Compte compte=new Compte(getRequest().getParameter("login"), getRequest().getParameter("password"), new SimpleDateFormat("yyyy-MM-dd").format(new Date()), new SimpleDateFormat("yyyy-MM-dd").format(new Date()),"ClientPhysique",false);
		Bilan bilan=new Bilan();
		ClientPhysique client=new ClientPhysique(getRequest().getParameter("email"),getRequest().getParameter("tel"),getRequest().getParameter("ville"), compte,getRequest().getParameter("pays"), bilan, getRequest().getParameter("cin"),getRequest().getParameter("nom"),getRequest().getParameter("prenom"),getRequest().getParameter("adresseP"),getRequest().getParameter("date_naissance"));
		bilan.setClient(client);
		
		if (getOfficeservices().nouveau_clientPhysique(client)) {
			getRequest().setAttribute("client_physique", client);
			getRequest().setAttribute("message", "client bien Ajouté");
			System.out.println("client bien Ajouté");
			return "/views/index.jsp";
		}
		else {
			getRequest().setAttribute("message", "Client non enregistré");
			System.out.println("client non Ajouté");
			return "/views/Error.jsp";

		}
	}
	
	public String nouveau_clientMorale(){
		Compte compte=new Compte(getRequest().getParameter("login"), getRequest().getParameter("password"), new SimpleDateFormat("yyyy-MM-dd").format(new Date()),new SimpleDateFormat("yyyy-MM-dd").format(new Date()),"ClientMorale",false);
		Bilan bilan=new Bilan();
		ClientMorale client=new ClientMorale(getRequest().getParameter("email"),getRequest().getParameter("tel"),getRequest().getParameter("ville"), compte,getRequest().getParameter("pays"), bilan, getRequest().getParameter("nomCabinet"),getRequest().getParameter("adresseM"));
		bilan.setClient(client);
		
		if (getOfficeservices().nouveau_clientMorale(client)) {
			getRequest().setAttribute("client_morale", client);
			getRequest().setAttribute("message", "client bien Ajouté");
			return "/views/index.jsp";
		}
		else {
			getRequest().setAttribute("message", "Client non enregistré");
			return "/views/Error.jsp";

		}
	}
	
	public String demanderRdv(){
		User user=getOfficeservices().authentification((String)(getRequest().getSession().getAttribute("login")),(String)(getRequest().getSession().getAttribute("password")));
		RendezVous rdv=new RendezVous(getRequest().getParameter("date"), false,(Client)user);
		
		if (getOfficeservices().demanderRdv(rdv)) {
			getRequest().setAttribute("rendez_vous",rdv);
			getRequest().setAttribute("message", "rendez-vous bien Ajouté");
			return "/views/rendezvous.jsp";
		}
		else {
			getRequest().setAttribute("message", "Rendez-vous non enregistré");
			return "/views/Error.jsp";

		}
	}
	
	public String listerRdv(){
		User user=getOfficeservices().authentification((String)(getRequest().getSession().getAttribute("login")),(String)(getRequest().getSession().getAttribute("password")));
		
		List<RendezVous> list=getOfficeservices().listRdv(user.getCode());
		
		if (list!=null) {
			getRequest().setAttribute("list_rendez_vous",list);
			getRequest().setAttribute("message", "list des rendez-vous");
			return "/views/gestionRDVs.jsp";
		}
		else {
			getRequest().setAttribute("message", "Aucun rendez vous trouvé");
			return "/views/Error.jsp";

		}
	}
	
	public String listerAnalyses(){
		User user=getUser();
		List<Analyse> list=getOfficeservices().listAnalyses(user.getCode(),user.getCompte().getType());
		if (list!=null) {
			getRequest().setAttribute("list_analyse",list);
			getRequest().setAttribute("message", "list des analyses");
			return "/views/listAnalyses.jsp";
		}
		else {
			getRequest().setAttribute("message", "Aucune Analyse trouvé");
			return "/views/Error.jsp";

		}
	}
	public String recupererRdv(){
		RendezVous rdv=getOfficeservices().recupererRdv(Integer.parseInt(getRequest().getParameter("coderdv")));
		if (rdv!=null) {
			getRequest().setAttribute("rendez_vous_recuperer",rdv);
			getRequest().setAttribute("message", "rendez vous a modifier");
			return "/views/clientRDV.jsp";
		}
		else {
			getRequest().setAttribute("message", "Rendez vous inexistant ");
			return "/views/Error.jsp";

		}
	}
	
	public String modifierRdv(){
		System.out.println("code : "+getRequest().getParameter("code"));
		RendezVous rdv= getOfficeservices().recupererRdv(Integer.parseInt(getRequest().getParameter("code")));
		rdv.setDate(getRequest().getParameter("date"));
		
		if(getOfficeservices().modifierRdv(rdv)){
			getRequest().setAttribute("rendez_vous",rdv);
			getRequest().setAttribute("message", "rendez bien modifier");
			return "/views/rendezvous.jsp";
		}
		else {
			getRequest().setAttribute("message", "Rendez-vous non modifier");
			return "/views/Error.jsp";
		}
	}
	
	public String supprimerRdv(){
		if(getOfficeservices().supprimerRdv(Integer.parseInt((String)(getRequest().getParameter("coderdv"))))){
			
			getRequest().setAttribute("message", "rendez vous supprimer");
			return "/views/rendezvous.jsp";
		}
		else {
			getRequest().setAttribute("message", "Rendez-vous non supprimer");
			return "/views/Error.jsp";
		}
	}
	public String modifierProfile(){
		System.out.println("account ? :"+getRequest().getParameter("account"));
		switch (getRequest().getParameter("account")) {
		case "Physique":
			ClientPhysique client=(ClientPhysique)getUser();
			
			Compte compte=getOfficeservices().recupererCompte(client.getCompte().getCode());
			compte.setLogin(getRequest().getParameter("login"));
			compte.setPassword(getRequest().getParameter("password"));
			
			client.setAdresse(getRequest().getParameter("adresseP"));
			client.setCin(getRequest().getParameter("cin"));
			client.setCompte(compte);
			client.setDate_naissance(getRequest().getParameter("date_naissance"));
			client.setEmail(getRequest().getParameter("email"));
			client.setNom(getRequest().getParameter("nom"));
			client.setPays(getRequest().getParameter("pays"));
			client.setPrenom(getRequest().getParameter("prenom"));
			client.setTelephone(getRequest().getParameter("tel"));
			client.setVille(getRequest().getParameter("ville"));
			
			if(!getOfficeservices().modifierClientPhysique(client)) return  "/views/Error.jsp";
			break;
		case "Morale":
			ClientMorale clientM=(ClientMorale)getUser();
			
			Compte compteM=getOfficeservices().recupererCompte(clientM.getCompte().getCode());
			compteM.setLogin(getRequest().getParameter("login"));
			compteM.setPassword(getRequest().getParameter("password"));
			
			clientM.setAdresse(getRequest().getParameter("adresseM"));
			clientM.setCompte(compteM);
			clientM.setEmail(getRequest().getParameter("email"));
			clientM.setNom(getRequest().getParameter("nomCabinet"));
			clientM.setPays(getRequest().getParameter("pays"));
			clientM.setTelephone(getRequest().getParameter("tel"));
			clientM.setVille(getRequest().getParameter("ville"));
			
			if(!getOfficeservices().modifierClientMorale(clientM)) return "/views/Error.jsp" ;
			break;
		default:
			break;
			
		
		}
		return "/views/clientVue.jsp";
	}
	public User getUser(){
		return getOfficeservices().authentification((String)(getRequest().getSession().getAttribute("login")),(String)(getRequest().getSession().getAttribute("password"))); 
		
	}
	
}
