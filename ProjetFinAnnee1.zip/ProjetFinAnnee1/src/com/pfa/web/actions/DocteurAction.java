package com.pfa.web.actions;




import java.util.List;

import com.pfa.business.OfficeServices;
import com.pfa.jpa.RendezVous;

public class DocteurAction extends Action{

	public DocteurAction() {
	}

	public DocteurAction(OfficeServices officeServices) {
		super(officeServices);
		// TODO Auto-generated constructor stub
	}
	
	public String listerRdvDoc(){
		List<RendezVous> list=getOfficeservices().listRdvToday();
		if(list!=null) {
			getRequest().setAttribute("listRdvDoc",list );
			return "/views/RdvToday.jsp";
		}
		else return "/views/Error.jsp";
	}
}
