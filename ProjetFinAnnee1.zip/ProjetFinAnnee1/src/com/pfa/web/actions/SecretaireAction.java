package com.pfa.web.actions;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.pfa.business.OfficeServices;
import com.pfa.jpa.Analyse;
import com.pfa.jpa.Bilan;
import com.pfa.jpa.Compte;
import com.pfa.jpa.Docteur;
import com.pfa.jpa.RendezVous;
import com.pfa.jpa.ResultatAnalyse;
import com.pfa.jpa.Secretaire;
import com.pfa.jpa.User;

public class SecretaireAction extends Action{
	private final String UPLOAD_DIRECTORY = "uploads";
	public SecretaireAction() {
		// TODO Auto-generated constructor stub
	}

	public SecretaireAction(OfficeServices officeServices) {
		super(officeServices);
		// TODO Auto-generated constructor stub
	}

	public String listRdvNV(){
		List<RendezVous> list=getOfficeservices().listRdvNV();
		
		if(list!=null){
			getRequest().setAttribute("list_rdv_nv", list);
			getRequest().setAttribute("message", "list des rendez-vous nv");
			return "/views/gestionRDVsNV.jsp";
		}
		else {
			getRequest().setAttribute("message", "Aucun rendez vous trouvé");
			return "/views/Error.jsp";

		}
		
	}
	
	public String validerRdv(){
		if(getOfficeservices().validerRdv(Integer.parseInt(getRequest().getParameter("coderdv")))){
			
			return listRdvNV();
		}
		else {
			getRequest().setAttribute("message", "Aucun rendez vous trouvé");
			return "/views/Error.jsp";

		}
		
	}
	public String rejeterRdv(){
		if(getOfficeservices().rejeterRdv(Integer.parseInt(getRequest().getParameter("coderdv")))){
			
			return listRdvNV();
		}
		else {
			getRequest().setAttribute("message", "Aucun rendez vous trouvé");
			return "/views/Error.jsp";

		}
		
	}
	
	public String ajouterAnalyse(){
		Bilan bilan=getOfficeservices().recupererBilan(Integer.parseInt(getRequest().getParameter("bilan")));
		Docteur docteur=getOfficeservices().recupererDocteur(Integer.parseInt(getRequest().getParameter("docteur")));
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); String date = formatter.format(new Date());
		Analyse analyse=new Analyse(getRequest().getParameter("nom"), Float.parseFloat(getRequest().getParameter("prix")), getRequest().getParameter("type"),Integer.parseInt(getRequest().getParameter("duree")),null,date,getRequest().getParameter("paid").equals("True"), bilan, docteur);
		if(getOfficeservices().nouvelle_analyse(analyse)) return "/views/SecretaireVue.jsp";
		else {
			getRequest().setAttribute("message", "Erreur de saisie d'analyse");
			return "/views/Error.jsp";

		}
	}
	
	public String modifierProfile(){
		Secretaire secretaire=(Secretaire)getUser();
		Compte compte=getOfficeservices().recupererCompte(secretaire.getCompte().getCode());
		compte.setLogin(getRequest().getParameter("login"));
		compte.setPassword(getRequest().getParameter("password"));
		
		secretaire.setAdresse(getRequest().getParameter("adresse"));
		secretaire.setCin(getRequest().getParameter("cin"));
		secretaire.setCompte(compte);
		secretaire.setEmail(getRequest().getParameter("email"));
		secretaire.setNbr_enfants(Integer.parseInt(getRequest().getParameter("nbr_enfants")));
		secretaire.setNom(getRequest().getParameter("nom"));
		secretaire.setNumero_securite_social(getRequest().getParameter("social"));
		secretaire.setPrenom(getRequest().getParameter("prenom"));
		secretaire.setSituationFamiliale(getRequest().getParameter("situation_familiale"));
		secretaire.setTelephone(getRequest().getParameter("tel"));
		secretaire.setVille(getRequest().getParameter("ville"));
		
		if(getOfficeservices().modifySecretaire(secretaire)) return "/views/SecretaireVue.jsp";
		else {
			getRequest().setAttribute("message", "Erreur de modification de profil");
			return "/views/Error.jsp";

		} 
	}
	public String listAnalyseSR(){
		List<Analyse> list=getOfficeservices().listAnalysesSR();
		
		if (list!=null) {
			getRequest().setAttribute("list_analyse",list);
			getRequest().setAttribute("message", "list des analyses");
			return "/views/listAnalyseSR.jsp";
		}
		else {
			getRequest().setAttribute("message", "Aucune Analyse trouvé");
			return "/views/Error.jsp";

		}
	}
	
	public String addRA(){
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); String date = formatter.format(new Date());
		int code=-1;String titre=null;
		
		String uploadPath = getRequest().getServletContext().getRealPath("")
			    + File.separator+UPLOAD_DIRECTORY;
		File uploadDir = new File(uploadPath);
		if (!uploadDir.exists()) {
		    uploadDir.mkdir();
		}
	        //process only if its multipart content
	        if(ServletFileUpload.isMultipartContent(getRequest())){
	            try {
	                List<FileItem> multiparts = new ServletFileUpload(
	                                         new DiskFileItemFactory()).parseRequest(getRequest());
	                String inputName = null;
	                for(FileItem item : multiparts){
	                    if(!item.isFormField()){
	                    	String fieldname = item.getFieldName();System.out.println("hihihihi : "+fieldname);
	                        String fieldvalue = item.getString();System.out.println(fieldvalue);
	                        String name = new File(item.getName()).getName();
	                        System.out.println(uploadPath);
	                        item.write( new File(uploadPath+ File.separator +code+".png"));
	                    }
	                    
	                    if(item.isFormField()){  // Check regular field.
	                    	  inputName = (String)item.getFieldName(); 
	                    	  if(inputName.equalsIgnoreCase("code")){ 
	                    	   code =Integer.parseInt( (String)item.getString()); 
	                    	    System.out.println("code = "+code);      
	                    	  }
	                    	  if(inputName.equalsIgnoreCase("titre")){ 
		                    	   titre =(String)item.getString(); 
		                    	       System.out.println("titre =  "+titre);   
		                    	  }
	                    	  
	                    	 } 
	                    
	                }
	           
	               //File uploaded successfully
	               getRequest().setAttribute("message", "File Uploaded Successfully");System.out.println("File Uploaded Successfully");
	               String path=(uploadPath+File.separator+code+".png").replace(" ", "%20");System.out.println(path);
	               ResultatAnalyse rs=new ResultatAnalyse(date,titre,path);
	               getOfficeservices().ajouterRA(code, rs);
	               
	               return "/views/insertRA.jsp";
	            } catch (Exception ex) {
	            	System.out.println(ex.getMessage());
	               getRequest().setAttribute("message", "File Upload Failed due to " + ex);
	               return "/views/Error.jsp";
	            }          
	         
	        }else{
	            getRequest().setAttribute("message",
	                                 "Sorry this Servlet only handles file upload request");System.out.println("erreuuur");
	            return "/views/Error.jsp";
	            
	        }
	}
	
	public User getUser(){
		return getOfficeservices().authentification((String)(getRequest().getSession().getAttribute("login")),(String)(getRequest().getSession().getAttribute("password"))); 
		
	}
	
	
}
