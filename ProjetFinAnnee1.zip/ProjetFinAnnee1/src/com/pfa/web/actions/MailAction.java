package com.pfa.web.actions;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.pfa.business.OfficeServices;



public class MailAction extends Action {

	public MailAction() {
		
	}

	public MailAction(OfficeServices officeServices) {
		super(officeServices);
		// TODO Auto-generated constructor stub
	}
	public void send(){
		
		System.out.println((String)(getRequest().getParameter("email"))+"   "+(String)(getRequest().getParameter("message"))+"\n\nName : "+(String)(getRequest().getParameter("name")));
		// Recipient's email ID needs to be mentioned.
	      String to = "otmane.ansari@usmba.ac.ma";

	      // Sender's email ID needs to be mentioned
	      String from =(String)(getRequest().getParameter("email")) ;

	      // Assuming you are sending email from localhost
	      String host = "localhost";

	      // Get system properties
	      Properties properties = System.getProperties();

	      // Setup mail server
	      properties.setProperty("mail.smtp.host", "smtp.gmail.com");
	      properties.put("mail.smtp.starttls.enable","true"); 
	      properties.put("mail.smtp.EnableSSL.enable","true");
	      properties.put("mail.smtp.auth", "true");
	      
	      // Get the default Session object.
	      Session session = Session.getDefaultInstance(properties);

	      try{
	         // Create a default MimeMessage object.
	         MimeMessage message = new MimeMessage(session);

	         // Set From: header field of the header.
	         message.setFrom(new InternetAddress(from));

	         // Set To: header field of the header.
	         message.addRecipient(Message.RecipientType.TO,
	                                  new InternetAddress(to));

	         // Set Subject: header field
	         message.setSubject((String)(getRequest().getParameter("subject")));

	         // Now set the actual message
	         message.setText((String)("Email : "+from+"\n\n"+getRequest().getParameter("message"))+"\n\nName : "+(String)(getRequest().getParameter("name")));

	         // Send message
	         Transport.send(message,"otmane.ansari@usmba.ac.ma","xxxxx");
	         System.out.println("Sent message successfully....");
	      }catch (MessagingException mex) {
	         mex.printStackTrace();
	      }
	}
}
