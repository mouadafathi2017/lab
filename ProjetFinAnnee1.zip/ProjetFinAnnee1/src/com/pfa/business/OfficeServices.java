package com.pfa.business;

import java.util.List;

import com.pfa.jpa.Analyse;
import com.pfa.jpa.Bilan;
import com.pfa.jpa.ClientMorale;
import com.pfa.jpa.ClientPhysique;
import com.pfa.jpa.Compte;
import com.pfa.jpa.Docteur;
import com.pfa.jpa.RendezVous;
import com.pfa.jpa.ResultatAnalyse;
import com.pfa.jpa.Secretaire;
import com.pfa.jpa.User;

public interface OfficeServices {
	public boolean nouveau_clientPhysique(ClientPhysique client_physique);
	public boolean nouveau_clientMorale(ClientMorale client_morale);
	public User authentification(String login, String password);/* action --> UserAction et ajouté une variable de session 'type' et 'user'*/
	public boolean demanderRdv(RendezVous rdv);
	public List<RendezVous> listRdv(int code_client);
	public List<Analyse> listAnalyses(int code_client,String type);
	public RendezVous recupererRdv(int code_rdv);
	public Bilan recupererBilan(int code_Bilan);
	public Docteur recupererDocteur(int code_docteur);
	public boolean modifierRdv(RendezVous rdv);
	public boolean supprimerRdv(int code_rdv);
	public Compte recupererCompte(int code_compte);
	public boolean modifierCompte(Compte compte);
	public boolean modifierClientPhysique(ClientPhysique client_physique);
	public boolean modifierClientMorale(ClientMorale client_morale);
	public ResultatAnalyse recupererResultatAnalyse(int code_analyse);
	public List<RendezVous> listRdvToday();
	public List<RendezVous> listRdvNV();
	public boolean validerRdv(int code_rdv);
	public boolean rejeterRdv(int code_rdv);
	public boolean nouvelle_analyse(Analyse analyse);
	public boolean modifySecretaire(Secretaire secretaire);
	public List<Analyse> listAnalysesSR();
	public boolean ajouterRA(int code_analyse,ResultatAnalyse rs);
}
