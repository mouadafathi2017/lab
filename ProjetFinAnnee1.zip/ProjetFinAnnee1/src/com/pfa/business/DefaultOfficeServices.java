package com.pfa.business;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.pfa.dao.AnalyseDao;
import com.pfa.dao.BilanDao;
import com.pfa.dao.ClientMoraleDao;
import com.pfa.dao.ClientPhysiqueDao;
import com.pfa.dao.CompteDao;
import com.pfa.dao.DocteurDao;
import com.pfa.dao.PaimentDao;
import com.pfa.dao.RendezVousDao;
import com.pfa.dao.SecretaireDao;
import com.pfa.jpa.Analyse;
import com.pfa.jpa.Bilan;
import com.pfa.jpa.ClientMorale;
import com.pfa.jpa.ClientPhysique;
import com.pfa.jpa.Compte;
import com.pfa.jpa.Docteur;
import com.pfa.jpa.RendezVous;
import com.pfa.jpa.ResultatAnalyse;
import com.pfa.jpa.Secretaire;
import com.pfa.jpa.User;

public class DefaultOfficeServices implements OfficeServices{
	public AnalyseDao analysedao;
	public BilanDao bilandao;
	public ClientMoraleDao clientmoraledao;
	public ClientPhysiqueDao clientphysiquedao;
	public CompteDao comptedao;
	public DocteurDao docteurdao;
	public PaimentDao paimentdao;
	public RendezVousDao rendezvousdao;
	public SecretaireDao secretairedao;

	
	public DefaultOfficeServices() {
		
	}

	public DefaultOfficeServices(AnalyseDao analysedao, BilanDao bilandao,
			ClientMoraleDao clientmoraledao,
			ClientPhysiqueDao clientphysiquedao, CompteDao comptedao,
			DocteurDao docteurdao, PaimentDao paimentdao,
			RendezVousDao rendezvousdao, SecretaireDao secretairedao) {
		super();
		this.analysedao = analysedao;
		this.bilandao = bilandao;
		this.clientmoraledao = clientmoraledao;
		this.clientphysiquedao = clientphysiquedao;
		this.comptedao = comptedao;
		this.docteurdao = docteurdao;
		this.paimentdao = paimentdao;
		this.rendezvousdao = rendezvousdao;
		this.secretairedao = secretairedao;
	}

	public DefaultOfficeServices(BilanDao bildao,SecretaireDao secdao,DocteurDao docdao,AnalyseDao analysedao,RendezVousDao rendezvousdao,ClientPhysiqueDao clientphysiquedao,ClientMoraleDao clientmoraledao,CompteDao comptedao) {
		super();
		this.analysedao = analysedao;
		this.clientphysiquedao = clientphysiquedao;
		this.clientmoraledao = clientmoraledao;
		this.comptedao=comptedao;
		this.rendezvousdao=rendezvousdao;
		this.docteurdao=docdao;
		this.secretairedao=secdao;
		this.bilandao=bildao;
	}

	public AnalyseDao getAnalysedao() {
		return analysedao;
	}

	public void setAnalysedao(AnalyseDao analysedao) {
		this.analysedao = analysedao;
	}

	public BilanDao getBilandao() {
		return bilandao;
	}

	public void setBilandao(BilanDao bilandao) {
		this.bilandao = bilandao;
	}

	public ClientMoraleDao getClientmoraledao() {
		return clientmoraledao;
	}

	public void setClientmoraledao(ClientMoraleDao clientmoraledao) {
		this.clientmoraledao = clientmoraledao;
	}

	public ClientPhysiqueDao getClientphysiquedao() {
		return clientphysiquedao;
	}

	public void setClientphysiquedao(ClientPhysiqueDao clientphysiquedao) {
		this.clientphysiquedao = clientphysiquedao;
	}

	public CompteDao getComptedao() {
		return comptedao;
	}

	public void setComptedao(CompteDao comptedao) {
		this.comptedao = comptedao;
	}

	public DocteurDao getDocteurdao() {
		return docteurdao;
	}

	public void setDocteurdao(DocteurDao docteurdao) {
		this.docteurdao = docteurdao;
	}

	public PaimentDao getPaimentdao() {
		return paimentdao;
	}

	public void setPaimentdao(PaimentDao paimentdao) {
		this.paimentdao = paimentdao;
	}

	public RendezVousDao getRendezvousdao() {
		return rendezvousdao;
	}

	public void setRendezvousdao(RendezVousDao rendezvousdao) {
		this.rendezvousdao = rendezvousdao;
	}

	public SecretaireDao getSecretairedao() {
		return secretairedao;
	}

	public void setSecretairedao(SecretaireDao secretairedao) {
		this.secretairedao = secretairedao;
	}

	@Override
	public boolean nouveau_clientPhysique(ClientPhysique client_physique) {
		
		return clientphysiquedao.insert(client_physique);
	}

	@Override
	public boolean nouveau_clientMorale(ClientMorale client_morale) {
		
		return clientmoraledao.insert(client_morale);
	}

	@Override
	public User authentification(String login, String password) {
		Compte compte=comptedao.select(login,password);System.out.println(compte);
		User user=null;
		switch (compte.getType()) {
		case "ClientMorale":
			user=clientmoraledao.select("user_compteID",""+compte.getCode());
			break;

		case "ClientPhysique":
			user=clientphysiquedao.select("user_compteID",""+compte.getCode());
			break;
			
		case "Docteur":
			user=docteurdao.select("user_compteID",""+compte.getCode());
			break;
			
		case "Secretaire":
			user=secretairedao.select("user_compteID",""+compte.getCode());
			break;

		}
		
		return user;
		
	}

	@Override
	public boolean demanderRdv(RendezVous rdv) {
		return rendezvousdao.insert(rdv);
		
	}

	@Override
	public List<RendezVous> listRdv(int code_client) {
		return rendezvousdao.selectAll(code_client);
	}

	@Override
	public List<Analyse> listAnalyses(int code_client,String type) {
		int code_bilan=-1;
		switch(type)
		{
			case "ClientPhysique":
				code_bilan = clientphysiquedao.select(code_client).getBilan().getId();
				break;
			case "ClientMorale":
				code_bilan = clientmoraledao.select(code_client).getBilan().getId();
				break;
		}
			return analysedao.selectAll(code_bilan);
	}

	@Override
	public RendezVous recupererRdv(int code_rdv) {
		return rendezvousdao.select(code_rdv);
	}

	@Override
	public boolean modifierRdv(RendezVous rdv) {
		return rendezvousdao.update(rdv);
	}

	@Override
	public boolean supprimerRdv(int code_rdv) {
		return rendezvousdao.delete(code_rdv);

	}

	@Override
	public Compte recupererCompte(int code_compte) {
		return comptedao.select(code_compte);
	}

	@Override
	public boolean modifierCompte(Compte compte) {
		return comptedao.update(compte);
	}
	
	@Override
	public ResultatAnalyse recupererResultatAnalyse(int code_analyse) {
		Analyse analyse=analysedao.select(code_analyse);
		return analyse.getResAnalyse();
	}

	@Override
	public boolean modifierClientPhysique(ClientPhysique client_physique) {
		
		return clientphysiquedao.update(client_physique);
	}

	@Override
	public boolean modifierClientMorale(ClientMorale client_morale) {
		
		return clientmoraledao.update(client_morale);
	}

	@Override
	public List<RendezVous> listRdvToday() {
		List<RendezVous> list=rendezvousdao.selectAll();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); 
		String date=formatter.format(new Date());System.out.println(date);
		List<RendezVous> result=new ArrayList<RendezVous>();
		for(RendezVous rdv:list){ 
			if((rdv.getDate().equals(date)) && rdv.isActive()) result.add(rdv);
			
		}
		
		return result;
	}

	@Override
	public List<RendezVous> listRdvNV() {
		List<RendezVous> list=rendezvousdao.selectAll();
		List<RendezVous> result=new ArrayList<RendezVous>();
		for(RendezVous rdv:list){ 
			if(!(rdv.isActive())) result.add(rdv);
			
		}
		
		return result;
	}

	@Override
	public boolean validerRdv(int code_rdv) {
		RendezVous rdv=rendezvousdao.select(code_rdv);
		if(rdv!=null){ rdv.setActive(true);return true;}
		else return false;
	}

	@Override
	public boolean rejeterRdv(int code_rdv) {
		 return rendezvousdao.delete(code_rdv);
	}


	@Override
	public Bilan recupererBilan(int code_Bilan) {
		return bilandao.select(code_Bilan);
	}

	@Override
	public Docteur recupererDocteur(int code_docteur) {
		return docteurdao.select(code_docteur);
	}

	@Override
	public boolean nouvelle_analyse(Analyse analyse) {
		return analysedao.insert(analyse);
	}

	@Override
	public boolean modifySecretaire(Secretaire secretaire) {
		return secretairedao.update(secretaire);
	}

	@Override
	public List<Analyse> listAnalysesSR() {
		List<Analyse> list=new ArrayList<Analyse>();
		for(Analyse anal:analysedao.selectAll()){
			if(anal.getResAnalyse()==null) list.add(anal);
		}
		return list;
	}

	@Override
	public boolean ajouterRA(int code_analyse,ResultatAnalyse rs) {
		Analyse an=analysedao.select(code_analyse);
		an.setResAnalyse(rs);
		if(analysedao.update(an)) return true;
		else return false;
	}
	
	
	
}
